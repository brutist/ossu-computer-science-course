/* *****************************************************************************
 *  Name:              Mauring Jr
 *  Coursera User ID:
 *  Last modified:     June 18, 2024
 **************************************************************************** */

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World");
    }
}
